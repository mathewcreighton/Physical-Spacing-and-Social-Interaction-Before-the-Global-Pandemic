########## 
Replication files for "How did we manage social distancing and social contact before the global pandemic?"
##########

In this folder, you will find the data and code required to reproduce the results reported in

"How did we manage social distancing and social contact before the global pandemic?"

These are the files contained in this folder:

### 0_ImportData.r
This code explains how to import the ESS data files and Interpersonal distance data by Sorokowska (2017). 

### 1_ProcessData.r
This code explains how to merge the three main datasets (ESS9, ESS previous rounds and IP distance). It also describes several variable transformations.  

### 2_Charts.r
Use this code to generate all charts included in the paper. 

If you do not want to change the analysis (by changing or including more variables), you can skip the previous two steps and load the working tables on the sub-folder /data. 




