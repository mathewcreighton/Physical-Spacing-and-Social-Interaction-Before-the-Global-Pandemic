# Interpersonal distance and ESS
# Analysing data (refer to 1_ProcessData.R on how to generate source tables)

# Required
library(tidyverse)
library(cluster) # clustering algorithms
library(factoextra) # clustering algorithms & visualization

# Loading tables

tb_cntry_overall <- read.csv("./data/overall.csv", sep = " ")
tb_cntry_age <- read.csv("./data/age.csv", sep = " ")
tb_cntry_gender <- read.csv("./data/gender.csv", sep = " ")


# Function to get the cluster chart

plot_cluster <- function(mytable) {
  scaled_table <- scale(mytable)
  kmeans_table <- kmeans(scaled_table, centers = 4, nstart = 25)
  fviz_cluster(kmeans_table, data = mytable, repel = TRUE)  +
    theme_bw()
}


# Overall pattern ----

get_overall <- function(freq_group, dist_group) {
  
  freq_group <- enquo(freq_group)
  dist_group <- enquo(dist_group)
  
  tb_cntry_overall %>%
    select(country, !!freq_group, !!dist_group) %>%
    filter(!is.na(!!freq_group)) %>%
    column_to_rownames(var = "country")
}

# Meet socially

tb_chart_meet_strang <- get_overall(meet_friends, stranger)
plot_cluster(tb_chart_meet_strang) + 
  labs(x = "How often socially meet with friends, relatives or colleagues",
       y = "Average distance",
       title = "Stranger")  + theme(legend.position="none")

tb_chart_meet_acqua <- get_overall(meet_friends, acquaintance)
plot_cluster(tb_chart_meet_acqua) + 
  labs(x = "How often socially meet with friends, relatives or colleagues",
       y = "",
       title = "Acquaintance") + theme(legend.position="none") 

tb_chart_meet_close <- get_overall(meet_friends, close_person)
plot_cluster(tb_chart_meet_close) + 
  labs(x = "How often socially meet with friends, relatives or colleagues",
       y = "",
       title = "Close person")  + theme(legend.position="none") 

# Church attendence

tb_chart_relig_strang <- get_overall(religion, stranger)
plot_cluster(tb_chart_relig_strang) + 
  labs(x = "How often attend religious services",
       y = "Average distance",
       title = "Stranger")  + theme(legend.position="none")

tb_chart_relig_acqua <- get_overall(religion, acquaintance)
plot_cluster(tb_chart_relig_acqua) + 
  labs(x = "How often attend religious services",
       y = "",
       title = "Acquaintance") + theme(legend.position="none") 

tb_chart_relig_close <- get_overall(religion, close_person)
plot_cluster(tb_chart_relig_close) + 
  labs(x = "How often attend religious services",
       y = "",
       title = "Close person")  + theme(legend.position="none") 

# Age pattern ----

tb_cluster_age_18 <-
  tb_cntry_age %>%
  select(country, meet_friends_18_39, religion_18_39, stranger_18_39, 
         close_person_18_39, acquaintance_18_39) %>%
  filter(!is.na(meet_friends_18_39)) %>%
  column_to_rownames(var = "country")

plot_cluster(tb_cluster_age_18) + 
  labs(title = "18 to 39 years old") + theme(legend.position="none") 

tb_cluster_age_40 <-
  tb_cntry_age %>%
  select(country, meet_friends_40_59, religion_40_59, stranger_40_59, close_person_40_59, 
         acquaintance_40_59) %>%
  filter(!is.na(meet_friends_40_59)) %>%
  column_to_rownames(var = "country")

plot_cluster(tb_cluster_age_40)+ 
  labs(title = "40 to 59 years old") + theme(legend.position="none")

tb_cluster_age_60 <-
  tb_cntry_age %>%
  select(country, `meet_friends_60+`, `religion_60+`, `stranger_60+`, 
         `close_person_60+`, `acquaintance_60+`) %>%
  filter(!is.na(`meet_friends_60+`)) %>%
  column_to_rownames(var = "country")

plot_cluster(tb_cluster_age_60) + 
  labs(title = "60 years old or more") + theme(legend.position="none")

# Gender pattern ----

tb_cluster_male <-
  tb_cntry_gender %>%
  select(country, meet_friends_M, religion_M, stranger_M, close_person_M, acquaintance_M) %>%
  filter(!is.na(meet_friends_M)) %>%
  column_to_rownames(var = "country")

plot_cluster(tb_cluster_male) + 
  labs(title = "Male") + theme(legend.position="none") 

tb_cluster_female <-
  tb_cntry_gender %>%
  select(country, meet_friends_F, religion_F, stranger_F, close_person_F, acquaintance_F) %>%
  filter(!is.na(meet_friends_F)) %>%
  column_to_rownames(var = "country")

plot_cluster(tb_cluster_female)  + 
  labs(title = "Female") + theme(legend.position="none") 


# Cluster overall ----

tb_cluster_overall <-
  tb_cntry_overall%>%
  select(country, meet_friends, religion, acquaintance, stranger, close_person) %>%
  filter(!is.na(meet_friends)) %>%
  column_to_rownames(var = "country")


plot_cluster(tb_cluster_overall)  + 
  labs(title = "Overall") + theme(legend.position="none") 

