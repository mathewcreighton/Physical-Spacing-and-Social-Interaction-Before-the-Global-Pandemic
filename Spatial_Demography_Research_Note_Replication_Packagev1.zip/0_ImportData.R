# Interpersonal distance and ESS
# Importing the datasets

# Required
library(tidyverse)
library(haven)
library(countrycode)

# 1) Interpersonal Distance data (Sorokowska et. al 2017) ----

df_ip_distance <- read_dta("./data/Interpersonal_Distance_Datav1.dta")

# ISO country code for ESS
df_ip_distance$cntry <- countrycode(df_ip_distance$nations,
                                    origin = "country.name",
                                    destination = "iso2c")

# Some values were not matched unambiguously: England
df_ip_distance$cntry[df_ip_distance$nations == "England"] <- "GB"

# Rename gender, age and education to match ess names

df_ip_distance <- 
  df_ip_distance %>% 
  rename(agea = age,
         eisced = edu) %>% 
  mutate(gndr = as.numeric(sex))


# 2) ESS data Round 9 and selecting relevant variables ----

# ESS Round 9: European Social Survey Round 9 Data (2018). Data file edition 1.1. 
# NSD - Norwegian Centre for Research Data, Norway – Data Archive and distributor of 
# ESS data for ESS ERIC. doi:10.21338/NSD-ESS9-2018.
# Access:  7 December 2019

df_ess9 <- read_sav("./data/ESS9e01_1.sav")

df_ess9_raw <- 
  df_ess9 %>% 
  select(cntry, essround, idno, agea, gndr, eisced, #control vars
          dweight, 
          sclmeet, #How often socially meet with friends
          inprdsc, #How many people with whom you can discuss intimate
          sclact, #Take part in social activities compared to others
          ppltrst, #most people can be trusted
          rlgatnd) %>% #How often attend religious services
  rename (pspwght = dweight)

rm(df_ess9)


# 3) ESS data previous rounds ----
# Loading data for countries that have no data available for ESS9

# European Social Survey Cumulative File, ESS 1-8 (2018). Data file edition 1.0.
# NSD - Norwegian Centre for Research Data, Norway - Data Archive and distributor of ESS
# data for ESS ERIC. doi:10.21338/NSD-ESS-CUMULATIVE.
# Access:  7 December 2019

df_ess <- read_sav("./data/ESS1-8e01.sav")


# selecting countries/rounds 
df_ess_raw <- 
  filter(df_ess,
   (cntry == "ES" & essround == 8) |
     (cntry == "GR" & essround == 5) |
     (cntry == "HR" & essround == 5) |
     (cntry == "PT" & essround == 8) |
     (cntry == "RU" & essround == 8) |
     (cntry == "SK" & essround == 6) |
     (cntry == "TR" & essround == 4) |
     (cntry == "UA" & essround == 6))

# selecting variables

df_ess_raw <- 
  df_ess_raw %>% 
  select(cntry, essround, idno, agea, gndr, eisced, #control vars
          pspwght,
            sclmeet, #How often socially meet with friends
            inprdsc, #How many people with whom you can discuss intimate
            sclact, #Take part in social activities compared to others
            ppltrst, #most people can be trusted
            rlgatnd) #How often attend religious services 


# 4) Bind ESS rounds ----

df_ess_full <-
  bind_rows(df_ess_raw, df_ess9_raw)




