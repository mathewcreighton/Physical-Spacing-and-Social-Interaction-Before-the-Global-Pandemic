# Interpersonal distance and ESS
# Processing data (refer to 0_AccesData.R on how to get the datasets)

# Required
library(tidyverse)
library(haven)
library(countrycode)

# 1) Creating age groups and 3-letter country codes ----

df_ip_distance <- 
  df_ip_distance %>%
  mutate(age_group = case_when(
    agea > 17 & agea < 40 ~ "18_39",
    agea > 39 & agea < 60 ~ "40_59",
    agea > 60 ~ "60+",
    agea < 18 ~ NA_character_,
    is.na(agea) ~ NA_character_)) %>% 
  mutate(country = countrycode(cntry, origin = "iso2c", destination = "iso3c"))

df_ess_full <- 
  df_ess_full %>% 
  mutate(age_group = case_when(
    agea > 17 & agea < 40 ~ "18_39",
    agea > 39 & agea < 60 ~ "40_59",
    agea > 60 ~ "60+",
    agea < 18 ~ NA_character_,
    is.na(agea) ~ NA_character_)) %>% 
  mutate(country = countrycode(cntry, origin = "iso2c", destination = "iso3c"))

# inverting scale of attendance to religious services

df_ess_full <- 
  df_ess_full %>% 
    mutate(
      inv_relig = 8 - rlgatnd
    )

# 2) Aggregating both datasets ---- 

# a) ESS data


#function to aggregate

my_agg_ess <- function(mygroupvar) {
  
  myvar <- syms(mygroupvar)
  
  df_ess_full %>% 
    group_by(!!!myvar) %>% 
    summarise(
      meet_friends = weighted.mean(sclmeet, w = pspwght, na.rm = T),
      meet_friends_sd = sd(sclmeet, na.rm = T),
      people_intimate = weighted.mean(inprdsc, w = pspwght, na.rm = T),
      people_intimate_sd = sd(inprdsc, na.rm = T),
      social_actv = weighted.mean(sclact, w = pspwght, na.rm = T),
      social_actv_sd = sd(sclact, na.rm = T),
      religion = weighted.mean(inv_relig, w = pspwght, na.rm = T),
      religion_sd = sd(inv_relig, na.rm = T),
      trust_ppl = weighted.mean(ppltrst, w = pspwght, na.rm = T),
      trust_ppl_sd = sd(ppltrst, na.rm = T),
    )
}

tb_ess_overall <- my_agg_ess("country") #ESS overall
tb_ess_age <- my_agg_ess(c("country", "age_group")) %>% filter(!is.na(age_group)) #ESS age group
tb_ess_gender <- my_agg_ess(c("country", "gndr")) #ESS gender

# a) IP data
#function to aggregate


my_agg_ip <- function(mygroupvar) {
  
  myvar <- syms(mygroupvar)
  
  df_ip_distance %>% 
    group_by(!!!myvar) %>% 
    summarise(
      acquaintance = weighted.mean(acquaintance_20, na.rm = T),
      acquaintance_sd = sd(acquaintance_20, na.rm = T),
      stranger = weighted.mean(stranger_20, na.rm = T),
      stranger_sd = sd(stranger_20, na.rm = T),
      close_person = weighted.mean(closeperson_20, na.rm = T),
      close_person_sd = sd(closeperson_20, na.rm = T),
      ip_distance = weighted.mean(meandistance_20, na.rm = T),
      ip_distance_sd = sd(meandistance_20, na.rm = T)
    )
}

tb_ip_overall <- my_agg_ip ("country")
tb_ip_gender <- my_agg_ip (c("country", "gndr"))
tb_ip_age <- my_agg_ip (c("country", "age_group")) %>% filter(!is.na(age_group))


# 3) Merging both datasets ---- 

# Creating ideal country:
tb_nocovid <- data.frame(country = c(rep("Soc. Res.", 6)),
                         meet_friends = 3, 
                         stranger = 100, acquaintance = 100, close_person = 100, ip_distance = 100,
                         social_actv = 2, religion = 1,
                         age_group = c("NA", "NA", "NA", "18_39", "40_59", "60+"),
                         gender = c("NA", "M", "F", "NA", "NA", "NA"),
                         table = c("overall", "gender", "gender", rep("age_group", 3))) 

# Overall table
tb_cntry_overall <- 
  tb_ip_overall %>% 
  left_join(tb_ess_overall, by = "country") %>%
  bind_rows(subset(tb_nocovid, table == "overall")) %>%
  select(country, meet_friends, stranger, close_person, acquaintance, ip_distance, religion) 

write.table(tb_cntry_overall, "./data/overall.csv")

# Age group table
tb_cntry_age <- 
  tb_ip_age %>% 
  left_join(tb_ess_age, by = c("country", "age_group")) %>%
  bind_rows(subset(tb_nocovid, table == "age_group")) %>% 
  select(country, age_group, meet_friends, stranger, close_person, 
         acquaintance, ip_distance, religion) %>% 
  pivot_wider(names_from = age_group, values_from = meet_friends:religion)

write.table(tb_cntry_age, "./data/age.csv")


# Gender table
tb_cntry_gender <- 
  tb_ip_gender %>% 
  left_join(tb_ess_gender, by =  c("country", "gndr")) %>% 
  mutate(gender = if_else(gndr == 1, "M", "F")) %>% 
  bind_rows(subset(tb_nocovid, table == "gender")) %>% 
  select(country, gender, meet_friends, stranger, close_person, 
         acquaintance, ip_distance, religion) %>% 
  pivot_wider(names_from = gender, values_from = meet_friends:religion)

write.table(tb_cntry_gender, "./data/gender.csv")


